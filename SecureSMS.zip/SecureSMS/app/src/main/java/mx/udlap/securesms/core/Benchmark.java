package mx.udlap.securesms.core;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Repeatable timing experiment: for every scheme, generate keys several times,
 * then encrypt/decrypt fixed messages of several lengths, discarding warm-up runs.
 * Times use System.nanoTime() and are reported in milliseconds.
 */
public final class Benchmark {

    public interface Progress { void update(String line); }

    public static final class Config {
        public Scheme[] schemes = Scheme.values();
        public int[] messageLengths = {16, 64, 140};
        public int warmup = 10;
        public int iterations = 50;
        public int keygenRuns = 5;          // reduced automatically for big RSA keys
    }

    public static final class Result {
        public Scheme scheme;
        public int msgChars, plainBytes, cipherBytes, smsChars, smsSegments, rsaBlocks, iterations;
        public double keygenMeanMs, keygenSdMs;
        public double encMeanMs, encSdMs, encMedianMs;
        public double decMeanMs, decSdMs, decMedianMs;
    }

    private static final String SAMPLE =
            "Meet me at the UDLAP library at 5 pm. Bring the LIS4062 notes and the encrypted keys. "
          + "This SMS is protected with public-key cryptography. ";

    public static String message(int chars) {
        StringBuilder sb = new StringBuilder();
        while (sb.length() < chars) sb.append(SAMPLE);
        return sb.substring(0, chars);
    }

    private volatile boolean cancelled = false;
    public void cancel() { cancelled = true; }

    public List<Result> run(Config cfg, Progress progress) {
        List<Result> out = new ArrayList<>();
        for (Scheme s : cfg.schemes) {
            if (cancelled) break;
            int kgRuns = cfg.keygenRuns;
            if (s.family == Scheme.Family.RSA && s.keyBits >= 7680) kgRuns = 1;
            else if (s.family == Scheme.Family.RSA && s.keyBits >= 4096) kgRuns = Math.min(kgRuns, 3);

            double[] kg = new double[kgRuns];
            KeyPair kp = null;
            try {
                for (int i = 0; i < kgRuns; i++) {
                    progress.update(s.label + ": key generation " + (i + 1) + "/" + kgRuns);
                    long t0 = System.nanoTime();
                    kp = SmsCrypto.generateKeyPair(s);
                    kg[i] = (System.nanoTime() - t0) / 1e6;
                }
            } catch (GeneralSecurityException | RuntimeException e) {
                progress.update(s.label + ": SKIPPED (" + e.getClass().getSimpleName() + ": " + e.getMessage() + ")");
                continue;
            }

            for (int len : cfg.messageLengths) {
                if (cancelled) break;
                progress.update(s.label + ": " + len + "-char message");
                byte[] plain = message(len).getBytes(StandardCharsets.UTF_8);
                double[] enc = new double[cfg.iterations];
                double[] dec = new double[cfg.iterations];
                byte[] ct = null;
                try {
                    for (int i = -cfg.warmup; i < cfg.iterations; i++) {
                        long t0 = System.nanoTime();
                        ct = SmsCrypto.encrypt(s, kp.getPublic(), plain);
                        long t1 = System.nanoTime();
                        byte[] back = SmsCrypto.decrypt(s, kp.getPrivate(), ct);
                        long t2 = System.nanoTime();
                        if (!Arrays.equals(back, plain)) throw new IllegalStateException("round-trip mismatch");
                        if (i >= 0) { enc[i] = (t1 - t0) / 1e6; dec[i] = (t2 - t1) / 1e6; }
                    }
                } catch (GeneralSecurityException | RuntimeException e) {
                    progress.update(s.label + ": ERROR " + e);
                    continue;
                }
                Result r = new Result();
                r.scheme = s;
                r.msgChars = len;
                r.plainBytes = plain.length;
                r.cipherBytes = ct.length;
                r.smsChars = SmsCodec.frameChars(s, ct.length);
                r.smsSegments = SmsCodec.smsSegments(r.smsChars);
                r.rsaBlocks = s.family == Scheme.Family.RSA ? SmsCrypto.rsaBlocks(s.keyBits, plain.length) : 0;
                r.iterations = cfg.iterations;
                r.keygenMeanMs = mean(kg); r.keygenSdMs = sd(kg);
                r.encMeanMs = mean(enc); r.encSdMs = sd(enc); r.encMedianMs = median(enc);
                r.decMeanMs = mean(dec); r.decSdMs = sd(dec); r.decMedianMs = median(dec);
                out.add(r);
                progress.update(String.format(Locale.US, "%s %3d ch | enc %.3f ms | dec %.3f ms | %d SMS",
                        s.label, len, r.encMeanMs, r.decMeanMs, r.smsSegments));
            }
        }
        return out;
    }

    public static String toCsv(List<Result> rs, String deviceInfo) {
        StringBuilder sb = new StringBuilder();
        sb.append("# ").append(deviceInfo.replace('\n', ' ')).append('\n');
        sb.append("scheme,family,key_bits,security_bits,msg_chars,plain_bytes,cipher_bytes,rsa_blocks,"
                + "sms_chars,sms_segments,iterations,keygen_mean_ms,keygen_sd_ms,"
                + "enc_mean_ms,enc_sd_ms,enc_median_ms,dec_mean_ms,dec_sd_ms,dec_median_ms\n");
        for (Result r : rs) {
            sb.append(String.format(Locale.US,
                    "%s,%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%.3f,%.3f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f\n",
                    r.scheme.label, r.scheme.family, r.scheme.keyBits, r.scheme.securityBits,
                    r.msgChars, r.plainBytes, r.cipherBytes, r.rsaBlocks, r.smsChars, r.smsSegments,
                    r.iterations, r.keygenMeanMs, r.keygenSdMs,
                    r.encMeanMs, r.encSdMs, r.encMedianMs, r.decMeanMs, r.decSdMs, r.decMedianMs));
        }
        return sb.toString();
    }

    static double mean(double[] a) { double s = 0; for (double v : a) s += v; return s / a.length; }

    static double sd(double[] a) {
        if (a.length < 2) return 0;
        double m = mean(a), s = 0;
        for (double v : a) s += (v - m) * (v - m);
        return Math.sqrt(s / (a.length - 1));
    }

    static double median(double[] a) {
        double[] b = a.clone(); Arrays.sort(b);
        int n = b.length;
        return n % 2 == 1 ? b[n / 2] : (b[n / 2 - 1] + b[n / 2]) / 2;
    }
}
