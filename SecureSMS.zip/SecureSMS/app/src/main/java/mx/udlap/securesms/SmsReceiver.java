package mx.udlap.securesms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import mx.udlap.securesms.core.SmsCodec;
import mx.udlap.securesms.core.SmsCrypto;

/**
 * Receives incoming SMS. The telephony framework reassembles concatenated SMS
 * before broadcasting, so all segments of one message arrive in a single intent.
 */
public class SmsReceiver extends BroadcastReceiver {

    static final String TAG = "SecureSMS";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        SmsMessage[] parts = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (parts == null) return;

        Map<String, StringBuilder> bySender = new LinkedHashMap<>();
        for (SmsMessage m : parts) {
            String from = m.getOriginatingAddress();
            StringBuilder sb = bySender.get(from);
            if (sb == null) { sb = new StringBuilder(); bySender.put(from, sb); }
            sb.append(m.getMessageBody());
        }

        KeyRepo repo = new KeyRepo(ctx);
        for (Map.Entry<String, StringBuilder> e : bySender.entrySet()) {
            handle(repo, e.getKey(), e.getValue().toString(), parts.length);
        }
    }

    static void handle(KeyRepo repo, String from, String body, int segments) {
        SmsCodec.Frame f = SmsCodec.decode(body);
        if (f == null) return; // ordinary SMS, ignore
        String time = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());

        if (SmsCodec.PK.equals(f.type)) {
            repo.savePeer(from, f.scheme, f.payload);
            String fp;
            try { fp = SmsCrypto.fingerprint(SmsCrypto.decodePublic(f.scheme, f.payload)); }
            catch (Exception ex) { fp = "invalid key"; }
            Inbox.add(time + "  KEY " + f.scheme + " from " + from + "\n  fingerprint " + fp
                    + "  (" + body.length() + " chars, " + segments + " SMS)");
            return;
        }

        KeyPair own = repo.own(f.scheme);
        if (own == null) {
            Inbox.add(time + "  " + f.scheme + " message from " + from + " but no own " + f.scheme + " key");
            return;
        }
        try {
            long t0 = System.nanoTime();
            byte[] plain = SmsCrypto.decrypt(f.scheme, own.getPrivate(), f.payload);
            double ms = (System.nanoTime() - t0) / 1e6;
            String text = new String(plain, StandardCharsets.UTF_8);
            Inbox.add(String.format(Locale.US,
                    "%s  FROM %s [%s]\n  cipher: %d chars / %d SMS\n  decrypted in %.3f ms\n  > %s",
                    time, from, f.scheme, body.length(), segments, ms, text));
            repo.appendLive(String.format(Locale.US, "recv,%s,%d,%d,%d,%.4f",
                    f.scheme.label, plain.length, body.length(), segments, ms));
            Log.i(TAG, "RX " + f.scheme + " dec_ms=" + ms + " cipher=" + body);
        } catch (Exception ex) {
            Inbox.add(time + "  " + f.scheme + " from " + from + ": DECRYPTION FAILED (" + ex.getMessage() + ")");
        }
    }
}
