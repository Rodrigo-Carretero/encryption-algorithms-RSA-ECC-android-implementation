package mx.udlap.securesms;

import java.util.ArrayList;
import java.util.List;

/** In-process event list shared by the SMS receiver and the activity (both run on the main thread). */
public final class Inbox {

    public interface Listener { void onEntry(String entry); }

    private static final List<String> ENTRIES = new ArrayList<>();
    private static Listener listener;

    private Inbox() {}

    public static synchronized void add(String entry) {
        ENTRIES.add(0, entry);
        if (listener != null) listener.onEntry(entry);
    }

    public static synchronized List<String> all() { return new ArrayList<>(ENTRIES); }

    public static synchronized void setListener(Listener l) { listener = l; }
}
