package mx.udlap.securesms;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.PublicKey;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;

import mx.udlap.securesms.core.Benchmark;
import mx.udlap.securesms.core.Scheme;
import mx.udlap.securesms.core.SmsCodec;
import mx.udlap.securesms.core.SmsCrypto;

public class MainActivity extends Activity {

    private KeyRepo repo;
    private Spinner spinner;
    private EditText editPhone, editMessage;
    private TextView txtMyKey, txtEstimate, txtOutgoing, txtInbox, txtBench;
    private Button btnGenKey, btnBenchmark;
    private String lastCsv = null;
    private final List<String> benchLines = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        repo = new KeyRepo(this);

        spinner = findViewById(R.id.spinnerScheme);
        editPhone = findViewById(R.id.editPhone);
        editMessage = findViewById(R.id.editMessage);
        txtMyKey = findViewById(R.id.txtMyKey);
        txtEstimate = findViewById(R.id.txtEstimate);
        txtOutgoing = findViewById(R.id.txtOutgoing);
        txtInbox = findViewById(R.id.txtInbox);
        txtBench = findViewById(R.id.txtBench);
        btnGenKey = findViewById(R.id.btnGenKey);
        btnBenchmark = findViewById(R.id.btnBenchmark);

        ArrayAdapter<Scheme> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Scheme.values());
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setSelection(Scheme.RSA_2048.ordinal());
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { showMyKey(); updateEstimate(); }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });
        editMessage.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { updateEstimate(); }
        });

        btnGenKey.setOnClickListener(v -> generateKey());
        findViewById(R.id.btnSendKey).setOnClickListener(v -> sendMyPublicKey());
        findViewById(R.id.btnSend).setOnClickListener(v -> encryptAndSend());
        findViewById(R.id.btnSelfTest).setOnClickListener(v -> selfTest());
        btnBenchmark.setOnClickListener(v -> runBenchmark());
        findViewById(R.id.btnShare).setOnClickListener(v -> shareCsv());

        requestPermissions(new String[]{Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS}, 1);
        showMyKey();
        updateEstimate();
    }

    @Override protected void onResume() {
        super.onResume();
        Inbox.setListener(e -> refreshInbox());
        refreshInbox();
    }

    @Override protected void onPause() {
        Inbox.setListener(null);
        super.onPause();
    }

    private Scheme scheme() { return (Scheme) spinner.getSelectedItem(); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    // ------------------------------------------------------------------ keys

    private void showMyKey() {
        Scheme s = scheme();
        KeyPair kp = repo.own(s);
        if (kp == null) {
            txtMyKey.setText("No " + s + " key pair yet. Tap \"Generate key pair\".");
        } else {
            txtMyKey.setText(s + " public key: " + kp.getPublic().getEncoded().length
                    + " bytes (X.509)\nfingerprint " + SmsCrypto.fingerprint(kp.getPublic()));
        }
    }

    private void generateKey() {
        final Scheme s = scheme();
        btnGenKey.setEnabled(false);
        txtMyKey.setText("Generating " + s + " key pair...");
        new Thread(() -> {
            try {
                long t0 = System.nanoTime();
                KeyPair kp = SmsCrypto.generateKeyPair(s);
                double ms = (System.nanoTime() - t0) / 1e6;
                repo.saveOwn(s, kp);
                runOnUiThread(() -> {
                    showMyKey();
                    txtMyKey.append(String.format(Locale.US, "\ngenerated in %.1f ms", ms));
                    btnGenKey.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    txtMyKey.setText(s + " not supported on this device: " + e.getMessage());
                    btnGenKey.setEnabled(true);
                });
            }
        }).start();
    }

    private void sendMyPublicKey() {
        Scheme s = scheme();
        KeyPair kp = repo.own(s);
        String to = editPhone.getText().toString().trim();
        if (kp == null) { toast("Generate your " + s + " key pair first"); return; }
        if (TextUtils.isEmpty(to)) { toast("Enter the contact's phone number"); return; }
        String text = SmsCodec.encode(SmsCodec.PK, s, kp.getPublic().getEncoded());
        if (sendSms(to, text)) {
            txtOutgoing.setText(String.format(Locale.US, "Public key %s sent to %s\n%d chars -> %d SMS\nfingerprint %s",
                    s, to, text.length(), SmsCodec.smsSegments(text.length()), SmsCrypto.fingerprint(kp.getPublic())));
        }
    }

    // -------------------------------------------------------------- messages

    private int cipherBytesFor(Scheme s, int plainBytes) {
        if (s.family == Scheme.Family.RSA) return SmsCrypto.rsaBlocks(s.keyBits, plainBytes) * (s.keyBits / 8);
        return SmsCrypto.eciesSize(s, plainBytes);
    }

    private void updateEstimate() {
        Scheme s = scheme();
        int n = editMessage.getText().toString().getBytes(StandardCharsets.UTF_8).length;
        int ct = cipherBytesFor(s, n);
        int chars = SmsCodec.frameChars(s, ct);
        String blocks = s.family == Scheme.Family.RSA
                ? String.format(Locale.US, " | %d RSA block(s) of max %d B", SmsCrypto.rsaBlocks(s.keyBits, n), SmsCrypto.rsaMaxBlock(s.keyBits))
                : "";
        txtEstimate.setText(String.format(Locale.US, "%d B plaintext -> %d B ciphertext -> %d chars -> %d SMS%s",
                n, ct, chars, SmsCodec.smsSegments(chars), blocks));
    }

    private void encryptAndSend() {
        Scheme s = scheme();
        String to = editPhone.getText().toString().trim();
        String msg = editMessage.getText().toString();
        if (TextUtils.isEmpty(to) || msg.isEmpty()) { toast("Enter phone number and message"); return; }
        PublicKey peer = repo.peer(to, s);
        if (peer == null) {
            toast("No " + s + " public key from " + to + ". Ask them to send theirs first.");
            return;
        }
        try {
            byte[] plain = msg.getBytes(StandardCharsets.UTF_8);
            long t0 = System.nanoTime();
            byte[] ct = SmsCrypto.encrypt(s, peer, plain);
            double ms = (System.nanoTime() - t0) / 1e6;
            String text = SmsCodec.encode(SmsCodec.CT, s, ct);
            if (sendSms(to, text)) {
                int segs = SmsCodec.smsSegments(text.length());
                txtOutgoing.setText(String.format(Locale.US,
                        "TO %s [%s]\nencrypted in %.3f ms\n%d B -> %d B -> %d chars -> %d SMS\n%s",
                        to, s, ms, plain.length, ct.length, text.length(), segs, text));
                repo.appendLive(String.format(Locale.US, "send,%s,%d,%d,%d,%.4f",
                        s.label, plain.length, text.length(), segs, ms));
                Log.i(SmsReceiver.TAG, "TX " + s + " enc_ms=" + ms + " cipher=" + text);
            }
        } catch (Exception e) {
            toast("Encryption failed: " + e.getMessage());
        }
    }

    /** Single-phone demo: encrypt with own public key, decrypt with own private key. No SMS is sent. */
    private void selfTest() {
        Scheme s = scheme();
        KeyPair kp = repo.own(s);
        String msg = editMessage.getText().toString();
        if (kp == null) { toast("Generate your " + s + " key pair first"); return; }
        if (msg.isEmpty()) { toast("Type a message"); return; }
        try {
            byte[] plain = msg.getBytes(StandardCharsets.UTF_8);
            long t0 = System.nanoTime();
            byte[] ct = SmsCrypto.encrypt(s, kp.getPublic(), plain);
            long t1 = System.nanoTime();
            byte[] back = SmsCrypto.decrypt(s, kp.getPrivate(), ct);
            long t2 = System.nanoTime();
            String text = SmsCodec.encode(SmsCodec.CT, s, ct);
            txtOutgoing.setText(String.format(Locale.US,
                    "SELF-TEST [%s]\nencrypt %.3f ms | decrypt %.3f ms\n%d B -> %d chars -> %d SMS\n%s\n> %s",
                    s, (t1 - t0) / 1e6, (t2 - t1) / 1e6, ct.length, text.length(),
                    SmsCodec.smsSegments(text.length()), text, new String(back, StandardCharsets.UTF_8)));
        } catch (Exception e) {
            toast("Self-test failed: " + e.getMessage());
        }
    }

    private boolean sendSms(String to, String text) {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS}, 1);
            toast("Grant the SMS permission and try again");
            return false;
        }
        try {
            SmsManager sms = Build.VERSION.SDK_INT >= 31 ? getSystemService(SmsManager.class) : SmsManager.getDefault();
            ArrayList<String> parts = sms.divideMessage(text);
            if (parts.size() == 1) sms.sendTextMessage(to, null, text, null, null);
            else sms.sendMultipartTextMessage(to, null, parts, null, null);
            return true;
        } catch (Exception e) {
            toast("SMS failed: " + e.getMessage());
            return false;
        }
    }

    private void refreshInbox() {
        List<String> all = Inbox.all();
        txtInbox.setText(all.isEmpty() ? "(nothing received yet)" : TextUtils.join("\n\n", all));
    }

    // ------------------------------------------------------------- benchmark

    private String deviceInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
          .append(", Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(')');
        if (Build.VERSION.SDK_INT >= 31) sb.append(", SoC ").append(Build.SOC_MANUFACTURER).append(' ').append(Build.SOC_MODEL);
        sb.append(", cores ").append(Runtime.getRuntime().availableProcessors());
        try {
            sb.append(", RSA provider ").append(Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding").getProvider().getName());
            sb.append(", ECDH provider ").append(KeyAgreement.getInstance("ECDH").getProvider().getName());
        } catch (Exception ignored) {}
        return sb.toString();
    }

    private void bench(String line) {
        runOnUiThread(() -> {
            benchLines.add(line);
            if (benchLines.size() > 60) benchLines.remove(0);
            txtBench.setText(TextUtils.join("\n", benchLines));
        });
    }

    private void runBenchmark() {
        btnBenchmark.setEnabled(false);
        benchLines.clear();
        final String info = deviceInfo();
        bench(info);
        bench("Running... keep the screen on and the phone plugged in.");
        new Thread(() -> {
            Benchmark.Config cfg = new Benchmark.Config();
            List<Benchmark.Result> results = new Benchmark().run(cfg, this::bench);
            String csv = Benchmark.toCsv(results, info);
            String name = "benchmark_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".csv";
            File f = new File(getExternalFilesDir(null), name);
            try (FileOutputStream out = new FileOutputStream(f)) {
                out.write(csv.getBytes(StandardCharsets.UTF_8));
            } catch (Exception e) {
                bench("Could not write file: " + e.getMessage());
            }
            lastCsv = csv;
            Log.i(SmsReceiver.TAG, "Benchmark CSV:\n" + csv);
            bench("DONE. Saved " + f.getAbsolutePath() + "\nTap \"Share CSV\" to email it to yourself.");
            runOnUiThread(() -> btnBenchmark.setEnabled(true));
        }).start();
    }

    private void shareCsv() {
        String live = repo.liveLog();
        if (lastCsv == null && live.isEmpty()) { toast("Run the benchmark first"); return; }
        String body = (lastCsv == null ? "" : lastCsv)
                + "\n# live SMS log: direction,scheme,plain_bytes,sms_chars,sms_segments,ms\n" + live;
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, "SecureSMS benchmark - " + Build.MODEL);
        i.putExtra(Intent.EXTRA_TEXT, body);
        startActivity(Intent.createChooser(i, "Share benchmark CSV"));
    }
}
