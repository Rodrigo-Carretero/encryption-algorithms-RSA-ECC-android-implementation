package mx.udlap.securesms;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;

import mx.udlap.securesms.core.Scheme;
import mx.udlap.securesms.core.SmsCodec;
import mx.udlap.securesms.core.SmsCrypto;

/**
 * Stores the user's own key pairs (one per scheme) and the public keys received
 * from contacts. Educational prototype: the private key lives in app-private
 * SharedPreferences; a production app would keep it in the Android Keystore.
 */
public final class KeyRepo {

    private final SharedPreferences prefs;

    public KeyRepo(Context ctx) {
        prefs = ctx.getApplicationContext().getSharedPreferences("keys", Context.MODE_PRIVATE);
    }

    /** Keeps the last 10 digits so "+52 222 123 4567" and "2221234567" match. */
    public static String normalize(String number) {
        String d = number == null ? "" : number.replaceAll("[^0-9]", "");
        return d.length() > 10 ? d.substring(d.length() - 10) : d;
    }

    public void saveOwn(Scheme s, KeyPair kp) {
        prefs.edit()
                .putString("own_pub_" + s.label, SmsCodec.b64(kp.getPublic().getEncoded()))
                .putString("own_priv_" + s.label, SmsCodec.b64(kp.getPrivate().getEncoded()))
                .apply();
    }

    public KeyPair own(Scheme s) {
        String pub = prefs.getString("own_pub_" + s.label, null);
        String priv = prefs.getString("own_priv_" + s.label, null);
        if (pub == null || priv == null) return null;
        try {
            PublicKey pk = SmsCrypto.decodePublic(s, SmsCodec.unb64(pub));
            PrivateKey sk = SmsCrypto.decodePrivate(s, SmsCodec.unb64(priv));
            return new KeyPair(pk, sk);
        } catch (Exception e) {
            return null;
        }
    }

    public void savePeer(String number, Scheme s, byte[] x509) {
        prefs.edit().putString("peer_" + normalize(number) + "_" + s.label, SmsCodec.b64(x509)).apply();
    }

    public PublicKey peer(String number, Scheme s) {
        String n = normalize(number);
        String v = prefs.getString("peer_" + n + "_" + s.label, null);
        if (v == null && n.length() >= 4) {
            // Fallback: "5556" (emulator) vs "15555215556", or 8-digit local vs 10-digit numbers
            String suffix = "_" + s.label;
            for (java.util.Map.Entry<String, ?> e : prefs.getAll().entrySet()) {
                String k = e.getKey();
                if (!k.startsWith("peer_") || !k.endsWith(suffix)) continue;
                String stored = k.substring(5, k.length() - suffix.length());
                if (stored.endsWith(n) || n.endsWith(stored)) { v = (String) e.getValue(); break; }
            }
        }
        if (v == null) return null;
        try {
            return SmsCrypto.decodePublic(s, SmsCodec.unb64(v));
        } catch (Exception e) {
            return null;
        }
    }

    public void appendLive(String csvLine) {
        String old = prefs.getString("live_log", "");
        prefs.edit().putString("live_log", old + csvLine + "\n").apply();
    }

    public String liveLog() { return prefs.getString("live_log", ""); }
}
