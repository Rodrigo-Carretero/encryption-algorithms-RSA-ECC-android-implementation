package mx.udlap.securesms.core;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.security.interfaces.RSAKey;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.ECParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.ECPublicKeySpec;
import java.security.spec.MGF1ParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAKeyGenParameterSpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;
import javax.crypto.spec.SecretKeySpec;

/**
 * Encryption core shared by the Android app and the desktop test harness.
 *
 * RSA : RSAES-OAEP (SHA-256, MGF1-SHA-256), RFC 8017. Messages longer than one
 *       OAEP block are split into fixed-size blocks; each ciphertext block is
 *       exactly k = keyBits/8 bytes, so the receiver splits on k.
 * ECC : ECIES-style hybrid scheme (SEC 1): ephemeral ECDH on the recipient's
 *       curve -> ANSI X9.63 KDF (SHA-256) -> AES-256-GCM.
 *       Output = ephemeral point (SEC 1; compressed except on P-224) || 12-byte IV || ciphertext || 16-byte tag.
 */
public final class SmsCrypto {

    private static final SecureRandom RNG = new SecureRandom();
    private static final String RSA_TRANSFORM = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding";
    private static final OAEPParameterSpec OAEP = new OAEPParameterSpec(
            "SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT);
    private static final int OAEP_HASH_LEN = 32;
    private static final int GCM_IV_LEN = 12;
    private static final int GCM_TAG_BITS = 128;

    private SmsCrypto() {}

    // ---------------------------------------------------------------- keys

    public static KeyPair generateKeyPair(Scheme s) throws GeneralSecurityException {
        if (s.family == Scheme.Family.RSA) {
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(new RSAKeyGenParameterSpec(s.keyBits, RSAKeyGenParameterSpec.F4), RNG);
            return g.generateKeyPair();
        } else {
            KeyPairGenerator g = KeyPairGenerator.getInstance("EC");
            g.initialize(new ECGenParameterSpec(s.curve), RNG);
            return g.generateKeyPair();
        }
    }

    private static String algName(Scheme s) {
        return s.family == Scheme.Family.RSA ? "RSA" : "EC";
    }

    public static PublicKey decodePublic(Scheme s, byte[] x509) throws GeneralSecurityException {
        return KeyFactory.getInstance(algName(s)).generatePublic(new X509EncodedKeySpec(x509));
    }

    public static PrivateKey decodePrivate(Scheme s, byte[] pkcs8) throws GeneralSecurityException {
        return KeyFactory.getInstance(algName(s)).generatePrivate(new PKCS8EncodedKeySpec(pkcs8));
    }

    /** Short SHA-256 fingerprint of a public key, for out-of-band verification. */
    public static String fingerprint(PublicKey pk) {
        try {
            byte[] h = MessageDigest.getInstance("SHA-256").digest(pk.getEncoded());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) {
                if (i > 0 && i % 2 == 0) sb.append(':');
                sb.append(String.format("%02X", h[i]));
            }
            return sb.toString();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }

    // ------------------------------------------------------------- dispatch

    public static byte[] encrypt(Scheme s, PublicKey pub, byte[] plain) throws GeneralSecurityException {
        return s.family == Scheme.Family.RSA ? rsaEncrypt(pub, plain) : eciesEncrypt((ECPublicKey) pub, plain);
    }

    public static byte[] decrypt(Scheme s, PrivateKey priv, byte[] ct) throws GeneralSecurityException {
        return s.family == Scheme.Family.RSA ? rsaDecrypt(priv, ct) : eciesDecrypt((ECPrivateKey) priv, ct);
    }

    // ------------------------------------------------------------------ RSA

    /** Max plaintext bytes in one OAEP-SHA-256 block: k - 2hLen - 2 (RFC 8017, 7.1.1). */
    public static int rsaMaxBlock(int keyBits) {
        return keyBits / 8 - 2 * OAEP_HASH_LEN - 2;
    }

    /** Number of RSA blocks needed for a plaintext of n bytes. */
    public static int rsaBlocks(int keyBits, int n) {
        int m = rsaMaxBlock(keyBits);
        return Math.max(1, (n + m - 1) / m);
    }

    private static int modulusBytes(java.security.Key k) {
        return (((RSAKey) k).getModulus().bitLength() + 7) / 8;
    }

    static byte[] rsaEncrypt(PublicKey pub, byte[] plain) throws GeneralSecurityException {
        int k = modulusBytes(pub);
        int max = k - 2 * OAEP_HASH_LEN - 2;
        Cipher c = Cipher.getInstance(RSA_TRANSFORM);
        c.init(Cipher.ENCRYPT_MODE, pub, OAEP, RNG);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int off = 0;
        do {
            int len = Math.min(max, plain.length - off);
            byte[] block = c.doFinal(plain, off, len);
            out.write(block, 0, block.length);
            off += len;
        } while (off < plain.length);
        return out.toByteArray();
    }

    static byte[] rsaDecrypt(PrivateKey priv, byte[] ct) throws GeneralSecurityException {
        int k = modulusBytes(priv);
        if (ct.length % k != 0) throw new GeneralSecurityException("Ciphertext is not a multiple of " + k + " bytes");
        Cipher c = Cipher.getInstance(RSA_TRANSFORM);
        c.init(Cipher.DECRYPT_MODE, priv, OAEP);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        for (int off = 0; off < ct.length; off += k) {
            byte[] block = c.doFinal(ct, off, k);
            out.write(block, 0, block.length);
        }
        return out.toByteArray();
    }

    // ---------------------------------------------------------------- ECIES

    private static int fieldBytes(ECParameterSpec p) {
        return (p.getCurve().getField().getFieldSize() + 7) / 8;
    }

    /**
     * Points are compressed only when p = 3 (mod 4) (P-256, P-384, P-521), where the square root is a
     * single exponentiation. P-224 has p = 1 (mod 4) with p - 1 divisible by 2^96, which makes
     * Tonelli-Shanks expensive, so its point is sent uncompressed.
     */
    static boolean compressPoints(ECParameterSpec p) {
        return ((java.security.spec.ECFieldFp) p.getCurve().getField()).getP().testBit(1);
    }

    /** Size in bytes of an ECIES ciphertext for a plaintext of n bytes. */
    public static int eciesSize(Scheme s, int n) {
        int f = (s.keyBits + 7) / 8;
        int point = "secp224r1".equals(s.curve) ? 1 + 2 * f : 1 + f;
        return point + GCM_IV_LEN + n + GCM_TAG_BITS / 8;
    }

    /** SEC 1 point: compressed 0x02/0x03 || x, or uncompressed 0x04 || x || y. */
    static byte[] encodePoint(ECPoint w, int f, boolean compress) {
        if (!compress) {
            byte[] out = new byte[1 + 2 * f];
            out[0] = 0x04;
            copyUnsigned(w.getAffineX(), out, 1, f);
            copyUnsigned(w.getAffineY(), out, 1 + f, f);
            return out;
        }
        byte[] out = new byte[1 + f];
        out[0] = (byte) (w.getAffineY().testBit(0) ? 0x03 : 0x02);
        copyUnsigned(w.getAffineX(), out, 1, f);
        return out;
    }

    private static void copyUnsigned(BigInteger v, byte[] dst, int off, int len) {
        byte[] b = v.toByteArray();
        int start = (b.length > len) ? b.length - len : 0;  // drop sign byte
        int n = b.length - start;
        System.arraycopy(b, start, dst, off + len - n, n);
    }

    /** Decodes a SEC 1 point; compressed points are recovered as y = sqrt(x^3 + ax + b) mod p. */
    static ECPublicKey decodePoint(byte[] enc, int off, ECParameterSpec p) throws GeneralSecurityException {
        int f = fieldBytes(p);
        byte tag = enc[off];
        BigInteger prime = ((java.security.spec.ECFieldFp) p.getCurve().getField()).getP();
        BigInteger x = new BigInteger(1, Arrays.copyOfRange(enc, off + 1, off + 1 + f));
        if (x.compareTo(prime) >= 0) throw new GeneralSecurityException("Invalid point");
        if (tag == 0x04) {
            BigInteger yy = new BigInteger(1, Arrays.copyOfRange(enc, off + 1 + f, off + 1 + 2 * f));
            return (ECPublicKey) KeyFactory.getInstance("EC").generatePublic(new ECPublicKeySpec(new ECPoint(x, yy), p));
        }
        if (tag != 0x02 && tag != 0x03) throw new GeneralSecurityException("Unknown point encoding");
        BigInteger rhs = x.pow(3).add(p.getCurve().getA().multiply(x)).add(p.getCurve().getB()).mod(prime);
        BigInteger y = sqrtMod(rhs, prime);
        if (y.testBit(0) != (tag == 0x03)) y = prime.subtract(y);
        return (ECPublicKey) KeyFactory.getInstance("EC").generatePublic(new ECPublicKeySpec(new ECPoint(x, y), p));
    }

    /** Modular square root: direct exponentiation when p = 3 (mod 4), Tonelli-Shanks otherwise (P-224). */
    static BigInteger sqrtMod(BigInteger n, BigInteger p) throws GeneralSecurityException {
        final BigInteger ONE = BigInteger.ONE;
        n = n.mod(p);
        if (n.signum() == 0) return n;
        BigInteger r;
        if (p.testBit(1)) {
            r = n.modPow(p.add(ONE).shiftRight(2), p);
        } else {
            BigInteger q = p.subtract(ONE);
            int s = 0;
            while (!q.testBit(0)) { q = q.shiftRight(1); s++; }
            BigInteger half = p.subtract(ONE).shiftRight(1);
            BigInteger z = BigInteger.valueOf(2);
            while (z.modPow(half, p).equals(ONE)) z = z.add(ONE);
            BigInteger c = z.modPow(q, p);
            BigInteger t = n.modPow(q, p);
            r = n.modPow(q.add(ONE).shiftRight(1), p);
            int m = s;
            while (!t.equals(ONE)) {
                int i = 0;
                BigInteger tt = t;
                while (!tt.equals(ONE)) {
                    tt = tt.multiply(tt).mod(p);
                    if (++i == m) throw new GeneralSecurityException("Point not on curve");
                }
                BigInteger b = c.modPow(ONE.shiftLeft(m - i - 1), p);
                r = r.multiply(b).mod(p);
                c = b.multiply(b).mod(p);
                t = t.multiply(c).mod(p);
                m = i;
            }
        }
        if (!r.multiply(r).mod(p).equals(n)) throw new GeneralSecurityException("Point not on curve");
        return r;
    }

    /** ANSI X9.63 KDF with SHA-256, one output block (32 bytes -> AES-256 key). */
    private static byte[] kdf(byte[] z, byte[] sharedInfo) throws GeneralSecurityException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(z);
        md.update(ByteBuffer.allocate(4).putInt(1).array());
        md.update(sharedInfo);
        return md.digest();
    }

    static byte[] eciesEncrypt(ECPublicKey recipient, byte[] plain) throws GeneralSecurityException {
        ECParameterSpec p = recipient.getParams();
        int f = fieldBytes(p);

        KeyPairGenerator g = KeyPairGenerator.getInstance("EC");
        g.initialize(p, RNG);
        KeyPair eph = g.generateKeyPair();

        KeyAgreement ka = KeyAgreement.getInstance("ECDH");
        ka.init(eph.getPrivate());
        ka.doPhase(recipient, true);
        byte[] z = ka.generateSecret();

        byte[] ephPoint = encodePoint(((ECPublicKey) eph.getPublic()).getW(), f, compressPoints(p));
        byte[] key = kdf(z, ephPoint);

        byte[] iv = new byte[GCM_IV_LEN];
        RNG.nextBytes(iv);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(GCM_TAG_BITS, iv));
        c.updateAAD(ephPoint);
        byte[] body = c.doFinal(plain);

        byte[] out = new byte[ephPoint.length + iv.length + body.length];
        System.arraycopy(ephPoint, 0, out, 0, ephPoint.length);
        System.arraycopy(iv, 0, out, ephPoint.length, iv.length);
        System.arraycopy(body, 0, out, ephPoint.length + iv.length, body.length);
        return out;
    }

    static byte[] eciesDecrypt(ECPrivateKey priv, byte[] ct) throws GeneralSecurityException {
        ECParameterSpec p = priv.getParams();
        int pl = (ct.length > 0 && ct[0] == 0x04) ? 1 + 2 * fieldBytes(p) : 1 + fieldBytes(p);
        if (ct.length < pl + GCM_IV_LEN + GCM_TAG_BITS / 8) throw new GeneralSecurityException("Ciphertext too short");

        byte[] ephPoint = Arrays.copyOfRange(ct, 0, pl);
        ECPublicKey eph = decodePoint(ct, 0, p);

        KeyAgreement ka = KeyAgreement.getInstance("ECDH");
        ka.init(priv);
        ka.doPhase(eph, true);
        byte[] key = kdf(ka.generateSecret(), ephPoint);

        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"),
                new GCMParameterSpec(GCM_TAG_BITS, ct, pl, GCM_IV_LEN));
        c.updateAAD(ephPoint);
        return c.doFinal(ct, pl + GCM_IV_LEN, ct.length - pl - GCM_IV_LEN);
    }
}
