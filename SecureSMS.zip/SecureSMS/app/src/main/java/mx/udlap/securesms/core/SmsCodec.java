package mx.udlap.securesms.core;

import java.util.Base64;

/**
 * Text framing for the SMS channel. Every character used here belongs to the
 * GSM 03.38 basic alphabet (Base64 + ':' + '-'), so each SMS segment carries
 * 160 characters (153 when the message is split into a concatenated SMS).
 *
 *   PK1:<scheme>:<base64 X.509 public key>     public-key announcement
 *   CT1:<scheme>:<base64 ciphertext>           encrypted message
 */
public final class SmsCodec {

    public static final String PK = "PK1";
    public static final String CT = "CT1";

    private SmsCodec() {}

    public static final class Frame {
        public final String type;
        public final Scheme scheme;
        public final byte[] payload;
        Frame(String type, Scheme scheme, byte[] payload) {
            this.type = type; this.scheme = scheme; this.payload = payload;
        }
    }

    public static String b64(byte[] b) { return Base64.getEncoder().encodeToString(b); }
    public static byte[] unb64(String s) { return Base64.getDecoder().decode(s); }

    public static String encode(String type, Scheme s, byte[] payload) {
        return type + ":" + s.label + ":" + b64(payload);
    }

    /** Returns null when the text is not one of our frames (ordinary SMS). */
    public static Frame decode(String text) {
        if (text == null) return null;
        String t = text.trim();
        if (!(t.startsWith(PK + ":") || t.startsWith(CT + ":"))) return null;
        String[] parts = t.split(":", 3);
        if (parts.length != 3) return null;
        try {
            return new Frame(parts[0], Scheme.fromLabel(parts[1]), unb64(parts[2]));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /** Segments needed for a GSM-7 text: 1 if <=160 chars, otherwise ceil(n/153). */
    public static int smsSegments(int chars) {
        return chars <= 160 ? 1 : (chars + 152) / 153;
    }

    /** Length of the SMS text that carries a ciphertext of n bytes. */
    public static int frameChars(Scheme s, int cipherBytes) {
        int b64 = 4 * ((cipherBytes + 2) / 3);
        return CT.length() + 1 + s.label.length() + 1 + b64;
    }
}
