package mx.udlap.securesms.core;

/**
 * Public-key configurations supported by the app.
 * securityBits follows NIST SP 800-57 Part 1 (Table 2); -1 = not tabulated by NIST.
 */
public enum Scheme {
    RSA_1024("RSA-1024", Family.RSA, 1024, 80, null),
    RSA_2048("RSA-2048", Family.RSA, 2048, 112, null),
    RSA_3072("RSA-3072", Family.RSA, 3072, 128, null),
    RSA_4096("RSA-4096", Family.RSA, 4096, -1, null),
    RSA_7680("RSA-7680", Family.RSA, 7680, 192, null),
    ECC_P224("ECC-P224", Family.ECC, 224, 112, "secp224r1"),
    ECC_P256("ECC-P256", Family.ECC, 256, 128, "secp256r1"),
    ECC_P384("ECC-P384", Family.ECC, 384, 192, "secp384r1"),
    ECC_P521("ECC-P521", Family.ECC, 521, 256, "secp521r1");

    public enum Family { RSA, ECC }

    public final String label;
    public final Family family;
    public final int keyBits;
    public final int securityBits;
    public final String curve;

    Scheme(String label, Family family, int keyBits, int securityBits, String curve) {
        this.label = label;
        this.family = family;
        this.keyBits = keyBits;
        this.securityBits = securityBits;
        this.curve = curve;
    }

    public static Scheme fromLabel(String label) {
        for (Scheme s : values()) if (s.label.equals(label)) return s;
        throw new IllegalArgumentException("Unknown scheme: " + label);
    }

    @Override public String toString() { return label; }
}
