#!/usr/bin/env python3
"""
LIS4062 Final Project - live demo: one SMS protected with RSA vs ECC.

Uses the SAME functions as ecc_rsa_benchmark.py (keep both files in one folder).

  python demo_ecc_sms.py                 # runs straight through
  python demo_ecc_sms.py --step          # waits for ENTER between steps (for recording)
  python demo_ecc_sms.py --rsa-bits 2048 # other NIST-equivalent pair (1024/2048/3072/7680)
  python demo_ecc_sms.py --msg "Your own text, up to 160 characters"
"""
import argparse
import base64
import time

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa

from ecc_rsa_benchmark import (PAIRS, SMS_CHARS, b64_len, ecc_decrypt,
                               ecc_encrypt, rsa_decrypt, rsa_encrypt, timed_ms)

LINE = "=" * 72


def ms_since(t0):
    return (time.perf_counter_ns() - t0) / 1e6


def short(b64, n=64):
    return b64 if len(b64) <= n else f"{b64[:n]} ... [{len(b64)} chars total]"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rsa-bits", type=int, default=3072, choices=sorted(PAIRS))
    ap.add_argument("--msg", default="Meet me at 6 PM at the library. Bring your notes.")
    ap.add_argument("--step", action="store_true",
                    help="wait for ENTER between steps")
    args = ap.parse_args()

    bits = args.rsa_bits
    cname, curve, sec = PAIRS[bits]
    msg = args.msg.encode("utf-8")

    def step(n, title):
        if args.step:
            input("\n[press ENTER for the next step] ")
        print(f"\n{LINE}\nSTEP {n}: {title}\n{LINE}")

    print(LINE)
    print(f"SMS encryption demo | RSA-{bits} vs ECC {cname} "
          f"(both ~{sec}-bit security, NIST SP 800-57)")
    print("RSA: RSA-OAEP (SHA-256)  |  ECC: ECIES = ECDH + HKDF-SHA256 + AES-256-GCM")
    print(LINE)

    # ------------------------------------------------------------ step 1
    step(1, "RECEIVER generates a key pair for each algorithm")
    t0 = time.perf_counter_ns()
    rkey = rsa.generate_private_key(65537, bits)
    t_rsa_kg = ms_since(t0)
    t0 = time.perf_counter_ns()
    ekey = ec.generate_private_key(curve)
    t_ecc_kg = ms_since(t0)
    ecc_pub = ekey.public_key().public_bytes(
        serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    print(f"RSA-{bits}: modulus = {rkey.public_key().public_numbers().n.bit_length()} bits"
          f" | key generation = {t_rsa_kg:10.3f} ms (single run)")
    print(f"ECC {cname}: public point = {len(ecc_pub)} bytes "
          f"(0x{ecc_pub[:12].hex()}...) | key generation = {t_ecc_kg:10.3f} ms (single run)")

    # ------------------------------------------------------------ step 2
    step(2, "SENDER writes the SMS")
    print(f'Plaintext : "{args.msg}"')
    print(f"Length    : {len(msg)} characters = {len(msg) * 8} bits "
          f"(one SMS holds {SMS_CHARS} characters)")
    if len(args.msg) > SMS_CHARS:
        print("WARNING: message is longer than one SMS.")

    # ------------------------------------------------------------ step 3
    step(3, "SENDER encrypts with the receiver's PUBLIC key")
    rct = rsa_encrypt(rkey.public_key(), bits, msg)
    ect = ecc_encrypt(ekey.public_key(), curve, msg)
    # same method as the benchmark: warm-up + mean of 100 runs (a single cold
    # call is dominated by start-up effects and is not representative)
    t_rsa_enc, _ = timed_ms(lambda: rsa_encrypt(rkey.public_key(), bits, msg), 100)
    t_ecc_enc, _ = timed_ms(lambda: ecc_encrypt(ekey.public_key(), curve, msg), 100)
    rb64 = base64.b64encode(rct).decode()
    eb64 = base64.b64encode(ect).decode()
    print(f"RSA-{bits}: {len(rct):4d} bytes -> Base64 {len(rb64):4d} chars -> "
          f"{-(-len(rb64) // SMS_CHARS)} SMS | encryption = {t_rsa_enc:8.3f} ms (mean of 100)")
    print(f"          {short(rb64)}")
    print(f"ECC {cname}: {len(ect):4d} bytes -> Base64 {len(eb64):4d} chars -> "
          f"{-(-len(eb64) // SMS_CHARS)} SMS | encryption = {t_ecc_enc:8.3f} ms (mean of 100)")
    print(f"          {short(eb64)}")
    print(f"ECC layout: ephemeral public key ({len(ecc_pub)} B) + nonce (12 B) "
          f"+ AES-GCM ciphertext+tag ({len(ect) - len(ecc_pub) - 12} B)")

    # ------------------------------------------------------------ step 4
    step(4, "RECEIVER decrypts with the PRIVATE key (this is what we time)")
    t0 = time.perf_counter_ns()
    r_plain = rsa_decrypt(rkey, bits, rct)
    t_rsa_dec1 = ms_since(t0)
    t0 = time.perf_counter_ns()
    e_plain = ecc_decrypt(ekey, curve, ect)
    t_ecc_dec1 = ms_since(t0)
    t_rsa_dec, _ = timed_ms(lambda: rsa_decrypt(rkey, bits, rct), 100)
    t_ecc_dec, _ = timed_ms(lambda: ecc_decrypt(ekey, curve, ect), 100)
    print(f'RSA-{bits}: "{r_plain.decode()}"  [{"OK" if r_plain == msg else "MISMATCH"}]')
    print(f'ECC {cname}: "{e_plain.decode()}"  [{"OK" if e_plain == msg else "MISMATCH"}]')
    print(f"\nDecryption time, first call : RSA {t_rsa_dec1:8.3f} ms | ECC {t_ecc_dec1:8.3f} ms")
    print(f"Decryption time, mean of 100: RSA {t_rsa_dec:8.3f} ms | ECC {t_ecc_dec:8.3f} ms"
          f"  ->  RSA/ECC = {t_rsa_dec / t_ecc_dec:.1f}x")

    # ------------------------------------------------------------ step 5
    step(5, "Tamper test: flip ONE byte of each ciphertext in transit")
    bad_r = bytearray(rct)
    bad_r[len(bad_r) // 2] ^= 0x01
    bad_e = bytearray(ect)
    bad_e[-1] ^= 0x01
    for label, fn, blob in ((f"RSA-{bits}", lambda b: rsa_decrypt(rkey, bits, b), bytes(bad_r)),
                            (f"ECC {cname}", lambda b: ecc_decrypt(ekey, curve, b), bytes(bad_e))):
        try:
            fn(blob)
            print(f"{label}: decrypted (unexpected)")
        except Exception as exc:  # noqa: BLE001 - demo output
            print(f"{label}: REJECTED ({type(exc).__name__})")

    # ------------------------------------------------------------ step 6
    step(6, "Summary for this one SMS")
    print(f"{'':16}{'RSA-' + str(bits):>14}{'ECC ' + cname:>14}")
    print(f"{'keygen (ms)*':16}{t_rsa_kg:14.3f}{t_ecc_kg:14.3f}")
    print(f"{'encrypt (ms)':16}{t_rsa_enc:14.3f}{t_ecc_enc:14.3f}")
    print(f"{'decrypt (ms)':16}{t_rsa_dec:14.3f}{t_ecc_dec:14.3f}")
    print(f"{'Base64 chars':16}{len(rb64):14d}{len(eb64):14d}")
    print(f"{'SMS needed':16}{-(-len(rb64) // SMS_CHARS):14d}{-(-len(eb64) // SMS_CHARS):14d}")
    print("\n* keygen = single run. Encrypt/decrypt = mean of 100 runs. "
          "The benchmark (200 runs) is the reference.")


if __name__ == "__main__":
    main()
