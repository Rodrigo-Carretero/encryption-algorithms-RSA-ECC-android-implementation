#!/usr/bin/env python3
"""
LIS4062 Final Project - RSA vs ECC benchmark harness (SMS-sized messages)

Measures, for NIST-equivalent security levels:
  1. Key generation time
  2. Encryption time
  3. Decryption time
  4. Ciphertext size (raw bytes, Base64 characters, number of SMS)

Design follows the course references:
  [1] Bodur & Kara   -> RSA + Base64 + splitting the message into blocks
  [2] Agoyi & Seral  -> keygen / enc / dec timing, averaged runs, SMS count
  [3] Jintcharadze   -> RSA vs ECC at equal NIST security, several text sizes

RSA : RSA-OAEP (SHA-256), message split into blocks if longer than one block.
ECC : ECIES = ephemeral ECDH + HKDF-SHA256 + AES-256-GCM
      (ECC does not encrypt directly; see [3], hybrid scheme with ECDH).

Usage:
  python ecc_rsa_benchmark.py                      # default: 1024 2048 3072
  python ecc_rsa_benchmark.py --sizes 1024 2048 3072 7680
  python ecc_rsa_benchmark.py --runs 200 --keygen-runs 5
"""
import argparse
import base64
import math
import os
import platform
import statistics
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

# NIST SP 800-57 equivalence (RSA bits -> ECC curve). P-192 stands in for the
# 160-bit level because secp160r1 is not available in this library.
PAIRS = {
    1024: ("P-192", ec.SECP192R1(), 80),
    2048: ("P-224", ec.SECP224R1(), 112),
    3072: ("P-256", ec.SECP256R1(), 128),
    7680: ("P-384", ec.SECP384R1(), 192),
    15360: ("P-521", ec.SECP521R1(), 256),
}

# Message sizes in characters (1 char = 1 byte = 8 bits here).
# 1 char = 8 bits, 8 = 64 bits, 32 = 256 bits (sizes used in [3]);
# 20 chars ~ 159 bits (message used in [2]); 160 = a full SMS.
MSG_SIZES = [1, 8, 20, 32, 160]

SMS_CHARS = 160  # one SMS = 160 GSM-7 characters = 1120 bits ([1], [2])
OAEP = padding.OAEP(mgf=padding.MGF1(hashes.SHA256()),
                    algorithm=hashes.SHA256(), label=None)


# ---------------------------------------------------------------- RSA
def rsa_block_size(bits):
    return bits // 8 - 2 * 32 - 2          # OAEP-SHA256 capacity in bytes


def rsa_encrypt(pub, bits, msg):
    bs = rsa_block_size(bits)
    return b"".join(pub.encrypt(msg[i:i + bs], OAEP)
                    for i in range(0, len(msg), bs))


def rsa_decrypt(priv, bits, ct):
    kb = bits // 8
    return b"".join(priv.decrypt(ct[i:i + kb], OAEP)
                    for i in range(0, len(ct), kb))


# ---------------------------------------------------------------- ECC
def _derive(shared):
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=None,
                info=b"sms-ecies").derive(shared)


def ecc_encrypt(recv_pub, curve, msg):
    eph = ec.generate_private_key(curve)
    key = _derive(eph.exchange(ec.ECDH(), recv_pub))
    nonce = os.urandom(12)
    ct = AESGCM(key).encrypt(nonce, msg, None)
    eph_pub = eph.public_key().public_bytes(
        serialization.Encoding.X962,
        serialization.PublicFormat.UncompressedPoint)
    return eph_pub + nonce + ct


def ecc_decrypt(priv, curve, blob):
    plen = 1 + 2 * math.ceil(curve.key_size / 8)
    eph_pub = ec.EllipticCurvePublicKey.from_encoded_point(curve, blob[:plen])
    key = _derive(priv.exchange(ec.ECDH(), eph_pub))
    return AESGCM(key).decrypt(blob[plen:plen + 12], blob[plen + 12:], None)


# ---------------------------------------------------------------- helpers
def timed_ms(fn, runs):
    """Return (mean_ms, stdev_ms) of fn() over `runs` runs, after a warm-up."""
    fn()
    samples = []
    for _ in range(runs):
        t0 = time.perf_counter_ns()
        fn()
        samples.append((time.perf_counter_ns() - t0) / 1e6)
    sd = statistics.stdev(samples) if runs > 1 else 0.0
    return statistics.mean(samples), sd


def b64_len(n):
    return 4 * math.ceil(n / 3)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sizes", type=int, nargs="+", default=[1024, 2048, 3072],
                    help="RSA key sizes (ECC curve chosen by NIST equivalence)")
    ap.add_argument("--runs", type=int, default=100,
                    help="runs per enc/dec measurement")
    ap.add_argument("--keygen-runs", type=int, default=5,
                    help="runs for key generation (paper [2] uses 5)")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    print("=" * 64)
    print("RSA vs ECC benchmark  |", platform.platform())
    print("Python", platform.python_version(), "|", platform.processor() or platform.machine())
    print("RSA sizes:", args.sizes, "| runs:", args.runs,
          "| keygen runs:", args.keygen_runs)
    print("=" * 64)

    keygen_rows, ed_rows, size_rows = [], [], []

    for bits in args.sizes:
        cname, curve, sec = PAIRS[bits]
        kg_runs = args.keygen_runs if bits <= 3072 else 1

        # ---- key generation
        m_rsa, s_rsa = timed_ms(
            lambda: rsa.generate_private_key(65537, bits), kg_runs) \
            if bits <= 3072 else (None, None)
        if m_rsa is None:                       # huge keys: no warm-up, 1 run
            t0 = time.perf_counter_ns()
            rsa.generate_private_key(65537, bits)
            m_rsa, s_rsa = (time.perf_counter_ns() - t0) / 1e6, 0.0
        m_ecc, s_ecc = timed_ms(lambda: ec.generate_private_key(curve), kg_runs)
        keygen_rows += [
            dict(security_bits=sec, algorithm="RSA", key_size=bits,
                 keygen_ms=m_rsa, keygen_sd=s_rsa),
            dict(security_bits=sec, algorithm="ECC", key_size=cname,
                 keygen_ms=m_ecc, keygen_sd=s_ecc)]
        print(f"[keygen] {sec:>3}-bit security | RSA-{bits}: {m_rsa:10.2f} ms"
              f" | ECC {cname}: {m_ecc:8.3f} ms")

        rkey = rsa.generate_private_key(65537, bits)
        ekey = ec.generate_private_key(curve)

        for n in MSG_SIZES:
            msg = os.urandom(n // 2 + 1).hex()[:n].encode()   # n ASCII chars

            # round-trip correctness check
            rct = rsa_encrypt(rkey.public_key(), bits, msg)
            ect = ecc_encrypt(ekey.public_key(), curve, msg)
            assert rsa_decrypt(rkey, bits, rct) == msg, "RSA round-trip failed"
            assert ecc_decrypt(ekey, curve, ect) == msg, "ECC round-trip failed"

            re_m, re_s = timed_ms(
                lambda: rsa_encrypt(rkey.public_key(), bits, msg), args.runs)
            rd_m, rd_s = timed_ms(lambda: rsa_decrypt(rkey, bits, rct), args.runs)
            ee_m, ee_s = timed_ms(
                lambda: ecc_encrypt(ekey.public_key(), curve, msg), args.runs)
            ed_m, ed_s = timed_ms(lambda: ecc_decrypt(ekey, curve, ect), args.runs)

            for alg, ks, em, es, dm, ds, ct in (
                    ("RSA", bits, re_m, re_s, rd_m, rd_s, rct),
                    ("ECC", cname, ee_m, ee_s, ed_m, ed_s, ect)):
                b64 = b64_len(len(ct))
                ed_rows.append(dict(
                    security_bits=sec, algorithm=alg, key_size=ks,
                    msg_chars=n, msg_bits=n * 8,
                    enc_ms=em, enc_sd=es, dec_ms=dm, dec_sd=ds))
                size_rows.append(dict(
                    security_bits=sec, algorithm=alg, key_size=ks,
                    msg_chars=n, msg_bits=n * 8, cipher_bytes=len(ct),
                    cipher_base64_chars=b64,
                    expansion_x=round(len(ct) / n, 2),
                    sms_needed=math.ceil(b64 / SMS_CHARS)))
            print(f"  msg={n:>3} chars | enc RSA {re_m:8.3f} / ECC {ee_m:8.3f} ms"
                  f" | dec RSA {rd_m:8.3f} / ECC {ed_m:8.3f} ms")

    kg = pd.DataFrame(keygen_rows)
    ed = pd.DataFrame(ed_rows)
    sz = pd.DataFrame(size_rows)
    kg.to_csv(f"{args.out}/keygen.csv", index=False)
    ed.to_csv(f"{args.out}/enc_dec.csv", index=False)
    sz.to_csv(f"{args.out}/cipher_size.csv", index=False)

    # ---------------------------------------------------------------- plots
    secs = sorted(kg.security_bits.unique())
    labels = [f"{s}-bit\nRSA-{b}/{PAIRS[b][0]}"
              for s, b in zip(secs, args.sizes)]

    def grouped_bar(ax, df, col, title, ylabel, log=True):
        w = 0.38
        x = range(len(secs))
        for i, alg in enumerate(("RSA", "ECC")):
            vals = [df[(df.security_bits == s) & (df.algorithm == alg)][col].iloc[0]
                    for s in secs]
            bars = ax.bar([p + (i - 0.5) * w for p in x], vals, w, label=alg)
            ax.bar_label(bars, fmt="%.2f", fontsize=7, padding=2)
        ax.set_xticks(list(x))
        ax.set_xticklabels(labels, fontsize=8)
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        if log:
            ax.set_yscale("log")
        ax.legend()
        ax.grid(axis="y", alpha=0.3)

    fig, ax = plt.subplots(figsize=(8, 4.5))
    grouped_bar(ax, kg, "keygen_ms", "Key generation time (lower is better)",
                "Time (ms, log scale)")
    fig.tight_layout()
    fig.savefig(f"{args.out}/fig1_keygen.png", dpi=200)
    plt.close(fig)

    ref = 20  # reference message (~159 bits, as in [2])
    for col, name, fn in (("enc_ms", "Encryption", "fig2_encryption.png"),
                          ("dec_ms", "Decryption", "fig3_decryption.png")):
        fig, ax = plt.subplots(figsize=(8, 4.5))
        grouped_bar(ax, ed[ed.msg_chars == ref], col,
                    f"{name} time, {ref}-char message (~{ref * 8} bits)",
                    "Time (ms, log scale)")
        fig.tight_layout()
        fig.savefig(f"{args.out}/{fn}", dpi=200)
        plt.close(fig)

    # time vs message size (one panel per metric, one line per algorithm/level)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    for ax, col, name in ((axes[0], "enc_ms", "Encryption"),
                          (axes[1], "dec_ms", "Decryption")):
        for s in secs:
            for alg, ls in (("RSA", "-"), ("ECC", "--")):
                d = ed[(ed.security_bits == s) & (ed.algorithm == alg)]
                ax.plot(d.msg_bits, d[col], ls, marker="o", markersize=4,
                        label=f"{alg} ({d.key_size.iloc[0]}) [{s}-bit sec.]")
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel("Message size (bits)")
        ax.set_ylabel("Time (ms)")
        ax.set_title(f"{name} time vs message size")
        ax.grid(alpha=0.3)
    axes[1].legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(f"{args.out}/fig4_time_vs_msgsize.png", dpi=200)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 4.5))
    d = sz[sz.msg_chars == 160]
    grouped_bar(ax, d, "cipher_base64_chars",
                "Ciphertext size for a full 160-char SMS (Base64 chars)",
                "Characters (log scale)")
    ax.axhline(SMS_CHARS, color="red", ls=":", lw=1)
    ax.text(0, SMS_CHARS * 1.05, "1 SMS = 160 chars", color="red", fontsize=8)
    fig.tight_layout()
    fig.savefig(f"{args.out}/fig5_cipher_size.png", dpi=200)
    plt.close(fig)

    # ---------------------------------------------------------------- tables
    pd.set_option("display.width", 200)
    pd.set_option("display.max_columns", 50)
    print("\n" + "=" * 64 + "\nTABLE A - Key generation (ms)\n" + "=" * 64)
    print(kg.round(3).to_string(index=False))
    print("\n" + "=" * 64 + "\nTABLE B - Encryption / decryption (ms)\n" + "=" * 64)
    print(ed.round(3).to_string(index=False))
    print("\n" + "=" * 64 + "\nTABLE C - Ciphertext size and SMS needed\n" + "=" * 64)
    print(sz.to_string(index=False))
    print(f"\nFiles saved in ./{args.out}/  (3 CSV + 5 PNG)")


if __name__ == "__main__":
    main()
